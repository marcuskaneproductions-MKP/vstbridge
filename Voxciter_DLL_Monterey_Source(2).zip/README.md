# Voxciter Native — macOS Monterey source prototype

## What was found in the archive

`Voxciter.dll` is a 32-bit Intel PE DLL from 2003 (`PE32`, i386). It exports one function named `main`. Its strings expose parameter names including `EQ1Gain`, `EQ1Freq`, `CmpGain`, `SdcGain`, `SdcFreq`, `EQ2Gain`, `EQ2Freq`, `DrvIGain`, `DrvOGain`, `RfsDrive`, `OutGain`, and `mixDryWet`, plus the product name `VoxCiter`. The file also contains a demo/licensing message.

The DLL has no original source code. This project is **not a literal decompilation** and does not reproduce the proprietary DSP exactly. It is a clean-room, JUCE-based approximation using common filter and soft-saturation building blocks, with parameter names informed by strings found in the binary. The exact meanings and scaling of those parameters are not known from strings alone.

## Build on macOS Monterey

1. Install Xcode Command Line Tools and CMake.
2. Download JUCE 7 or a compatible JUCE release and make its CMake package available.
3. From this folder, configure a build. Example, if JUCE is at `~/JUCE`:

   ```sh
   cmake -S . -B build -DJUCE_DIR="$HOME/JUCE"
   cmake --build build --config Release
   ```

   Depending on the JUCE installation, you may need to set `CMAKE_PREFIX_PATH` to the JUCE CMake package directory instead of `JUCE_DIR`.

4. The target formats are Audio Unit (`.component`), VST3, and Standalone. The source is intended to build on macOS Monterey, but has **not been compiled or tested in this environment**. Verify the JUCE version, build settings, host validation, audio stability, and sound before use.

## Known limitations

- This is not bit-identical or sonically validated against the original VoxCiter.
- There is no original GUI, preset format, licensing behavior, or demo behavior.
- The "Density" control is a simple harmonic-thickening approximation, not a recovered compressor.
- No compiled plugin binary is included; this archive contains source code only.
