#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <cmath>

namespace
{
    float getParam(juce::AudioProcessorValueTreeState& state, const char* id)
    {
        if (auto* p = state.getRawParameterValue(id))
            return p->load();
        return 0.0f;
    }

    float dbToGain(float db) { return juce::Decibels::decibelsToGain(db); }

    // Soft saturation used as a simple harmonic exciter. This is an original,
    // deliberately approximate DSP design, not recovered proprietary code.
    inline float saturate(float x, float drive)
    {
        const float d = juce::jmax(0.05f, drive);
        return std::tanh(x * d) / std::tanh(d);
    }
}

VoxciterNativeAudioProcessor::VoxciterNativeAudioProcessor()
    : AudioProcessor(BusesProperties()
        .withInput("Input", juce::AudioChannelSet::stereo(), true)
        .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      parameters(*this, nullptr, "PARAMETERS", createParameterLayout())
{
}

VoxciterNativeAudioProcessor::APVTS::ParameterLayout
VoxciterNativeAudioProcessor::createParameterLayout()
{
    APVTS::ParameterLayout p;
    auto addFloat = [&p](const char* id, const char* name, float lo, float hi, float def, float step = 0.0f)
    {
        p.add(std::make_unique<juce::AudioParameterFloat>(
            juce::ParameterID{id, 1}, name,
            juce::NormalisableRange<float>(lo, hi, step), def));
    };
    addFloat("mixDryWet", "Dry / Wet", 0.0f, 1.0f, 1.0f, 0.01f);
    addFloat("DrvIGain", "Drive Input", -18.0f, 18.0f, 0.0f, 0.1f);
    addFloat("RfsDrive", "Exciter Drive", 0.1f, 12.0f, 2.0f, 0.01f);
    addFloat("DrvOGain", "Drive Output", -18.0f, 18.0f, 0.0f, 0.1f);
    addFloat("CmpGain", "Density", 0.0f, 12.0f, 2.0f, 0.1f);
    addFloat("SdcGain", "Presence", -12.0f, 12.0f, 2.0f, 0.1f);
    addFloat("SdcFreq", "Presence Freq", 1000.0f, 12000.0f, 4500.0f, 1.0f);
    addFloat("EQ1Gain", "Low Shelf", -12.0f, 12.0f, 0.0f, 0.1f);
    addFloat("EQ1Freq", "Low Freq", 60.0f, 600.0f, 180.0f, 1.0f);
    addFloat("EQ2Gain", "High Shelf", -12.0f, 12.0f, 0.0f, 0.1f);
    addFloat("EQ2Freq", "High Freq", 3000.0f, 18000.0f, 9000.0f, 1.0f);
    addFloat("OutGain", "Output", -24.0f, 12.0f, 0.0f, 0.1f);
    return p;
}

void VoxciterNativeAudioProcessor::prepareToPlay(double sampleRate, int samplesPerBlock)
{
    currentSampleRate = sampleRate;
    juce::dsp::ProcessSpec spec { sampleRate, (juce::uint32) samplesPerBlock,
                                (juce::uint32) getTotalNumOutputChannels() };
    lowShelf.prepare(spec);
    highShelf.prepare(spec);
    presencePeak.prepare(spec);
    bodyPeak.prepare(spec);
    dryBuffer.setSize(getTotalNumOutputChannels(), samplesPerBlock);
    updateFilters();
    lowShelf.reset(); highShelf.reset(); presencePeak.reset(); bodyPeak.reset();
}

void VoxciterNativeAudioProcessor::releaseResources()
{
    lowShelf.reset(); highShelf.reset(); presencePeak.reset(); bodyPeak.reset();
}

bool VoxciterNativeAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
    const auto out = layouts.getMainOutputChannelSet();
    return (out == juce::AudioChannelSet::mono() || out == juce::AudioChannelSet::stereo())
        && out == layouts.getMainInputChannelSet();
}

void VoxciterNativeAudioProcessor::updateFilters()
{
    const auto sr = currentSampleRate;
    *lowShelf.state = *juce::dsp::IIR::Coefficients<float>::makeLowShelf(
        sr, getParam(parameters, "EQ1Freq"), 0.707f, dbToGain(getParam(parameters, "EQ1Gain")));
    *highShelf.state = *juce::dsp::IIR::Coefficients<float>::makeHighShelf(
        sr, juce::jmin(getParam(parameters, "EQ2Freq"), (float)(sr * 0.45)), 0.707f,
        dbToGain(getParam(parameters, "EQ2Gain")));
    *presencePeak.state = *juce::dsp::IIR::Coefficients<float>::makePeakFilter(
        sr, juce::jmin(getParam(parameters, "SdcFreq"), (float)(sr * 0.45)), 0.8f,
        dbToGain(getParam(parameters, "SdcGain")));
    *bodyPeak.state = *juce::dsp::IIR::Coefficients<float>::makePeakFilter(
        sr, 220.0f, 0.8f, dbToGain(getParam(parameters, "CmpGain") * 0.25f));
}

void VoxciterNativeAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    const int channels = getTotalNumOutputChannels();
    const int samples = buffer.getNumSamples();
    if (dryBuffer.getNumSamples() < samples)
        dryBuffer.setSize(channels, samples, false, false, true);

    for (int ch = 0; ch < channels; ++ch)
        dryBuffer.copyFrom(ch, 0, buffer, ch, 0, samples);

    // Keep coefficients responsive to automation and host parameter changes.
    updateFilters();
    juce::dsp::AudioBlock<float> block(buffer);
    juce::dsp::ProcessContextReplacing<float> context(block);
    lowShelf.process(context);
    highShelf.process(context);
    presencePeak.process(context);
    bodyPeak.process(context);

    const float inGain = dbToGain(getParam(parameters, "DrvIGain"));
    const float outDriveGain = dbToGain(getParam(parameters, "DrvOGain"));
    const float drive = getParam(parameters, "RfsDrive");
    const float density = getParam(parameters, "CmpGain");
    const float outGain = dbToGain(getParam(parameters, "OutGain"));
    const float mix = juce::jlimit(0.0f, 1.0f, getParam(parameters, "mixDryWet"));
    const float densityGain = dbToGain(density * 0.25f);

    for (int ch = 0; ch < channels; ++ch)
    {
        auto* wet = buffer.getWritePointer(ch);
        const auto* dry = dryBuffer.getReadPointer(ch);
        for (int n = 0; n < samples; ++n)
        {
            const float x = wet[n] * inGain;
            const float driven = saturate(x, drive) * outDriveGain;
            const float dense = driven * densityGain;
            // Gentle level-dependent thickening; intentionally not a full compressor.
            const float y = (driven + dense * std::tanh(std::abs(driven) * 2.0f)) * outGain;
            wet[n] = dry[n] * (1.0f - mix) + y * mix;
        }
    }
}

juce::AudioProcessorEditor* VoxciterNativeAudioProcessor::createEditor()
{
    return new juce::GenericAudioProcessorEditor(*this);
}

void VoxciterNativeAudioProcessor::getStateInformation(juce::MemoryBlock& destData)
{
    auto state = parameters.copyState();
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, destData);
}

void VoxciterNativeAudioProcessor::setStateInformation(const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xml(getXmlFromBinary(data, sizeInBytes));
    if (xml && xml->hasTagName(parameters.state.getType()))
        parameters.replaceState(juce::ValueTree::fromXml(*xml));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new VoxciterNativeAudioProcessor();
}
