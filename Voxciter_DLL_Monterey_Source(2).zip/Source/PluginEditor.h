#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"

class VoxciterNativeAudioProcessorEditor final : public juce::GenericAudioProcessorEditor
{
public:
    explicit VoxciterNativeAudioProcessorEditor(VoxciterNativeAudioProcessor& p)
        : juce::GenericAudioProcessorEditor(p) {}
};
