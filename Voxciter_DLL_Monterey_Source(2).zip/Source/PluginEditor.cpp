#include "PluginEditor.h"
// The generic JUCE parameter editor is used intentionally to keep this
// source-only prototype compact and cross-platform.
