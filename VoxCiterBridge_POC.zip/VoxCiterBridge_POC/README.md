# VoxCiter Bridge — proof-of-concept 0.1

This is the first engineering scaffold for testing a native macOS plug-in talking to a separate legacy Windows VST host. It is **source code only**; it is not a compiled plug-in and it does not yet load VoxCiter.dll.

## Why this is split into two processes

`Voxciter.dll.zip` contains a 32-bit Windows PE DLL. macOS cannot load that binary into a native AU/VST3 process. The intended design is:

1. A native 64-bit macOS AU/VST3 wrapper appears in the DAW.
2. A separate 32-bit-capable Windows compatibility process loads the original VST under a compatible runtime.
3. The two processes exchange audio blocks and parameter/state messages through shared memory.
4. The wrapper reports silence if the helper is not ready, rather than blocking the DAW audio thread.

The hardest parts are still ahead: a working Windows VST2 host adapter, compatibility-runtime packaging, crash recovery, parameter/state synchronization, and embedding the original GUI. The first milestone is to prove the transport and timing model before attempting the GUI.

## Contents

- `include/bridge_protocol.h` — fixed shared-memory protocol and slot states.
- `src/bridge_protocol.cpp` — transport-independent slot queue primitives.
- `tests/protocol_selftest.cpp` — in-process test for block publish/consume and sequence handling.
- `macOSPlugin/README.md` — integration notes for a JUCE AU/VST3 wrapper.
- `WindowsHost/README.md` — requirements for the legacy VST host side.
- `CMakeLists.txt` — builds the protocol self-test with CMake.

## Build the protocol self-test

Requires a C++17 compiler and CMake 3.20+:

```sh
cmake -S . -B build
cmake --build build
./build/protocol_selftest
```

This test validates the shared data/queue primitives only. It does **not** test inter-process audio, a DAW, Wine, or VoxCiter itself.

## Compatibility and licensing notes

- Target host: Intel Mac running macOS Monterey, as originally requested. Apple Silicon would need a separately validated strategy.
- The VoxCiter binary remains proprietary and is not included here.
- A VST2 host implementation must use a legally obtained VST2 SDK/header set or a carefully reviewed compatible ABI implementation. This scaffold deliberately does not bundle Steinberg SDK files.
- Do not put blocking locks, sleeps, socket waits, or helper startup on the DAW's real-time audio callback.

## Next acceptance tests

1. Build and run the protocol self-test.
2. Add a real shared-memory mapping and a separate helper process; test sequence numbers and underrun behavior.
3. Create a minimal native AU/VST3 wrapper that adds a known fixed latency and routes audio through the helper.
4. Load VoxCiter.dll in the helper under the selected compatibility runtime.
5. Verify wet audio, parameter changes, preset/state recall, and GUI separately.
