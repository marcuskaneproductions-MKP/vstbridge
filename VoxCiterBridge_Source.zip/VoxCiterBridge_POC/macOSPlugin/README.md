# Native macOS wrapper integration (next step)

Target: AU + VST3 built as 64-bit Intel for macOS Monterey, using JUCE supplied separately by the developer/build machine.

The wrapper should:

- expose a stereo in/stereo out effect;
- maintain a fixed, documented pipeline latency while the helper is running;
- write incoming audio blocks to an available shared-memory slot without waiting;
- read only the output sequence that is ready; on a miss, output the delayed dry signal or silence according to a user-selectable safe fallback;
- never launch the helper or block on IPC from `processBlock`;
- send parameter/state changes through a separate non-real-time control channel;
- surface helper status and latency in the GUI.

This directory is intentionally documentation-only at this milestone. A functional DAW plug-in requires the shared-memory mapper, helper lifecycle management, JUCE wrapper, and build/testing on an actual Intel Mac with Monterey.
