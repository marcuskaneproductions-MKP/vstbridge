#pragma once
#include <array>
#include <atomic>
#include <cstdint>
#include <cstddef>

namespace voxciter_bridge {

constexpr std::uint32_t kMagic = 0x56434231; // "VCB1"
constexpr std::uint32_t kProtocolVersion = 1;
constexpr std::size_t kMaxChannels = 2;
constexpr std::size_t kMaxFrames = 2048;
constexpr std::size_t kSlotCount = 8;

enum class SlotState : std::uint32_t { Empty = 0, Ready = 1, Processing = 2, Done = 3 };

struct alignas(64) AudioSlot {
    std::atomic<std::uint32_t> state{static_cast<std::uint32_t>(SlotState::Empty)};
    std::uint32_t channels = 2;
    std::uint32_t frames = 0;
    std::uint32_t flags = 0;
    std::uint64_t sequence = 0;
    float input[kMaxChannels * kMaxFrames]{};
    float output[kMaxChannels * kMaxFrames]{};
};

struct alignas(64) SharedBlock {
    std::uint32_t magic = kMagic;
    std::uint32_t version = kProtocolVersion;
    std::uint32_t slotCount = static_cast<std::uint32_t>(kSlotCount);
    std::uint32_t maxFrames = static_cast<std::uint32_t>(kMaxFrames);
    std::atomic<std::uint64_t> hostHeartbeat{0};
    std::atomic<std::uint64_t> pluginHeartbeat{0};
    std::atomic<std::uint32_t> helperReady{0};
    std::atomic<std::uint32_t> shutdownRequested{0};
    AudioSlot slots[kSlotCount];
};

// Producer owns Empty -> Ready. Consumer owns Ready -> Processing -> Done.
// The audio callback must never spin waiting for a slot or for helper output.
inline bool publishInput(AudioSlot& slot, const float* interleaved,
                         std::uint32_t channels, std::uint32_t frames,
                         std::uint64_t sequence) noexcept {
    if (!interleaved || channels == 0 || channels > kMaxChannels ||
        frames == 0 || frames > kMaxFrames) return false;
    std::uint32_t expected = static_cast<std::uint32_t>(SlotState::Empty);
    if (!slot.state.compare_exchange_strong(expected,
            static_cast<std::uint32_t>(SlotState::Processing),
            std::memory_order_acquire, std::memory_order_relaxed)) return false;
    slot.channels = channels;
    slot.frames = frames;
    slot.sequence = sequence;
    const std::size_t count = static_cast<std::size_t>(channels) * frames;
    for (std::size_t i = 0; i < count; ++i) slot.input[i] = interleaved[i];
    slot.state.store(static_cast<std::uint32_t>(SlotState::Ready), std::memory_order_release);
    return true;
}

inline bool claimInput(AudioSlot& slot) noexcept {
    std::uint32_t expected = static_cast<std::uint32_t>(SlotState::Ready);
    return slot.state.compare_exchange_strong(expected,
        static_cast<std::uint32_t>(SlotState::Processing),
        std::memory_order_acquire, std::memory_order_relaxed);
}

inline void completeOutput(AudioSlot& slot, const float* interleavedOutput) noexcept {
    const std::size_t count = static_cast<std::size_t>(slot.channels) * slot.frames;
    for (std::size_t i = 0; i < count; ++i) slot.output[i] = interleavedOutput[i];
    slot.state.store(static_cast<std::uint32_t>(SlotState::Done), std::memory_order_release);
}

inline bool consumeOutput(AudioSlot& slot, float* destination,
                          std::size_t destinationSamples,
                          std::uint64_t expectedSequence) noexcept {
    if (!destination) return false;
    if (slot.state.load(std::memory_order_acquire) != static_cast<std::uint32_t>(SlotState::Done) ||
        slot.sequence != expectedSequence) return false;
    const std::size_t count = static_cast<std::size_t>(slot.channels) * slot.frames;
    if (count > destinationSamples) return false;
    for (std::size_t i = 0; i < count; ++i) destination[i] = slot.output[i];
    slot.state.store(static_cast<std::uint32_t>(SlotState::Empty), std::memory_order_release);
    return true;
}

} // namespace voxciter_bridge
