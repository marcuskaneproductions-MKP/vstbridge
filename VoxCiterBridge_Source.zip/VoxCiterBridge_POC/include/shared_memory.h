#pragma once
#include "bridge_protocol.h"
#include <string>

namespace voxciter_bridge {

// Named, process-shared mapping for SharedBlock. The creator owns initialization;
// clients must only open after create() succeeds. Keep the mapping alive while
// any thread is using block().
class SharedMemoryRegion {
public:
    SharedMemoryRegion() noexcept = default;
    ~SharedMemoryRegion();
    SharedMemoryRegion(const SharedMemoryRegion&) = delete;
    SharedMemoryRegion& operator=(const SharedMemoryRegion&) = delete;
    SharedMemoryRegion(SharedMemoryRegion&& other) noexcept;
    SharedMemoryRegion& operator=(SharedMemoryRegion&& other) noexcept;

    bool create(const std::string& name, std::string* error = nullptr) noexcept;
    bool openExisting(const std::string& name, std::string* error = nullptr) noexcept;
    void close() noexcept;
    bool unlinkName(std::string* error = nullptr) noexcept;
    SharedBlock* block() noexcept { return block_; }
    const SharedBlock* block() const noexcept { return block_; }
    bool isCreator() const noexcept { return creator_; }
    explicit operator bool() const noexcept { return block_ != nullptr; }

private:
    void* address_ = nullptr;
    SharedBlock* block_ = nullptr;
    std::string name_;
    bool creator_ = false;
#ifdef _WIN32
    void* handle_ = nullptr;
#else
    int fd_ = -1;
#endif
};

} // namespace voxciter_bridge
