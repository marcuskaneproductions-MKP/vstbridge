#include "bridge_protocol.h"
#include <cmath>
#include <iostream>
#include <vector>

using namespace voxciter_bridge;

int main() {
    AudioSlot slot;
    constexpr std::uint32_t channels = 2;
    constexpr std::uint32_t frames = 128;
    constexpr std::uint64_t seq = 42;
    std::vector<float> input(channels * frames), output(channels * frames, 0.0f);
    for (std::size_t i = 0; i < input.size(); ++i)
        input[i] = static_cast<float>(std::sin(static_cast<double>(i) * 0.071));

    if (!publishInput(slot, input.data(), channels, frames, seq)) {
        std::cerr << "FAIL: could not publish input block\n"; return 1;
    }
    if (!claimInput(slot)) {
        std::cerr << "FAIL: helper could not claim block\n"; return 1;
    }
    // Simulate a transparent plugin/helper: output is identical to input.
    completeOutput(slot, slot.input);
    if (!consumeOutput(slot, output.data(), output.size(), seq)) {
        std::cerr << "FAIL: could not consume output block\n"; return 1;
    }
    for (std::size_t i = 0; i < input.size(); ++i) {
        if (std::fabs(input[i] - output[i]) > 1.0e-7f) {
            std::cerr << "FAIL: sample mismatch at " << i << "\n"; return 1;
        }
    }
    if (slot.state.load() != static_cast<std::uint32_t>(SlotState::Empty)) {
        std::cerr << "FAIL: slot did not return to Empty\n"; return 1;
    }
    std::cout << "PASS: block publish/claim/complete/consume; " << input.size()
              << " samples preserved; sequence=" << seq << "\n";
    return 0;
}
