#include "shared_memory.h"
#include <chrono>
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <string>
#include <thread>
#include <vector>
#ifdef _WIN32
#include <process.h>
#define getpid _getpid
#else
#include <unistd.h>
#endif
using namespace voxciter_bridge;

int worker(const std::string& name) {
    SharedMemoryRegion region; std::string error;
    if (!region.openExisting(name, &error)) { std::cerr << "worker open failed: " << error << "\n"; return 10; }
    auto* shared = region.block();
    shared->helperReady.store(1, std::memory_order_release);
    // The test process may wait, but this is deliberately not audio-thread code.
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(5);
    while (std::chrono::steady_clock::now() < deadline) {
        for (auto& slot : shared->slots) {
            if (claimInput(slot)) {
                completeOutput(slot, slot.input); // transparent test plugin
                shared->pluginHeartbeat.fetch_add(1, std::memory_order_relaxed);
                return 0;
            }
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
    std::cerr << "worker timed out waiting for audio block\n"; return 11;
}
int main(int argc, char** argv) {
    if (argc == 3 && std::string(argv[1]) == "--worker") return worker(argv[2]);
#ifdef _WIN32
    const std::string name = "Local\\VoxCiterBridgeTest_" + std::to_string(getpid());
#else
    const std::string name = "/VoxCiterBridgeTest_" + std::to_string(getpid());
#endif
    SharedMemoryRegion region; std::string error;
    if (!region.create(name, &error)) { std::cerr << "create failed: " << error << "\n"; return 1; }
    auto* shared = region.block();
    constexpr std::uint32_t channels = 2, frames = 257;
    constexpr std::uint64_t sequence = 9876;
    std::vector<float> input(channels * frames), output(channels * frames, -999.0f);
    for (std::size_t i = 0; i < input.size(); ++i) input[i] = std::sin(float(i) * 0.031f);
    bool published = false;
    for (auto& slot : shared->slots) if (publishInput(slot, input.data(), channels, frames, sequence)) { published = true; break; }
    if (!published) { std::cerr << "host could not publish block\n"; region.unlinkName(); return 2; }
    // Spawn an independent process that opens the mapping by name.
    std::string command = "\"" + std::string(argv[0]) + "\" --worker \"" + name + "\"";
    const int childStatus = std::system(command.c_str());
    if (childStatus != 0) { std::cerr << "worker process failed, status=" << childStatus << "\n"; region.unlinkName(); return 3; }
    bool consumed = false;
    for (auto& slot : shared->slots) if (consumeOutput(slot, output.data(), output.size(), sequence)) { consumed = true; break; }
    if (!consumed) { std::cerr << "host could not consume output block\n"; region.unlinkName(); return 4; }
    for (std::size_t i = 0; i < input.size(); ++i) if (std::fabs(input[i] - output[i]) > 1e-7f) {
        std::cerr << "sample mismatch at " << i << "\n"; region.unlinkName(); return 5;
    }
    if (shared->helperReady.load(std::memory_order_acquire) != 1 || shared->pluginHeartbeat.load() != 1) {
        std::cerr << "worker status fields not visible across processes\n"; region.unlinkName(); return 6;
    }
    region.unlinkName();
    std::cout << "PASS: separate process opened named shared memory; transferred " << input.size()
              << " float samples; sequence=" << sequence << "; status atomics visible\n";
    return 0;
}
