# VoxCiter Bridge — shared-memory transport POC 0.2

This revision implements a named shared-memory mapping and a separate-process integration test. It remains **source code / transport infrastructure only**: it is not a finished AU/VST3 plug-in, does not load `VoxCiter.dll`, and does not yet exchange audio with the original VoxCiter DSP.

## What is implemented

- `include/shared_memory.h`, `src/shared_memory.cpp`: RAII named mapping implementation. POSIX uses `shm_open` + `ftruncate` + `mmap(MAP_SHARED)` (macOS/Linux); Windows uses `CreateFileMapping` + `MapViewOfFile`.
- `include/bridge_protocol.h`: fixed-size audio slots, state transitions, sequence numbers and shared status atomics.
- `tests/shared_memory_process_test.cpp`: starts a second copy of the test executable. The child opens the named mapping independently, claims an audio block, copies samples through the shared slot and marks it complete. The parent checks the returned samples and shared status fields.
- `tests/protocol_selftest.cpp`: in-process protocol unit test.

## Build and run

Requires CMake 3.20+ and a C++17 compiler.

```sh
cmake -S . -B build
cmake --build build
ctest --test-dir build --output-on-failure
```

Expected tests: `protocol_selftest` and `shared_memory_process_test` pass. The cross-process test has been built and run in the current Linux development environment. The macOS and Windows implementations are included but still need to be built and tested on those operating systems.

## Shared-memory API sketch

The host creates a unique mapping name, then starts the helper with that name. The helper calls `openExisting(name)`; it must not initialize the mapped `SharedBlock`. Only the creator initializes it. Keep the mapping alive while any thread uses its block. POSIX names begin with `/`, for example `/voxciter_bridge_session1`; Windows uses a named mapping such as `Local\\VoxCiterBridge_session1`.

The test intentionally waits in a non-real-time test process. **Do not copy its waiting loop into a DAW audio callback.** The production callback must claim/publish without blocking and return silence or a defined fallback on underrun. The current slot protocol is a proof of concept; production audio needs careful latency budgeting, overrun recovery, helper crash handling, and parameter/state messages.

## Important integration boundary

A named POSIX mapping and a Windows named file mapping are not automatically the *same* mapping across operating-system namespaces. This implementation proves inter-process shared memory for two processes using the same OS mapping API. It does **not** yet prove that a native macOS AU/VST3 process can map the same memory as a Windows process under Wine. That cross-boundary integration must be tested on the target Intel Mac and may require a Wine-aware bridge/transport adapter. The original Windows DLL also needs a compatible 32-bit Windows VST host environment.

## Current status / next milestones

1. **Done in this revision:** shared-memory mapping implementation and a two-process round-trip test on Linux.
2. Build and run both tests on macOS Monterey (Intel) and Windows.
3. Decide and validate the native-macOS-to-Wine shared-memory boundary; do not assume the mapping names interoperate.
4. Implement a native AU/VST3 wrapper and a helper launcher.
5. Implement the legacy VST2 host ABI in the helper and load the user's legally obtained VoxCiter DLL.
6. Validate real audio, parameter automation, state recall, crash recovery and GUI embedding.

## Compatibility and licensing notes

- Target remains an Intel Mac running macOS Monterey.
- The VoxCiter binary is proprietary and is not included.
- The project does not bundle Steinberg VST2 SDK files.
- Shared `std::atomic` objects are checked for lock-free operation, but cross-process C++ atomic behavior still needs platform-specific validation.
