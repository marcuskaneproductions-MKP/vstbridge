#include "shared_memory.h"
#include <new>
#include <utility>
#include <cstring>

#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#else
#include <cerrno>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#endif

namespace voxciter_bridge {
namespace {
void setError(std::string* out, const char* message) noexcept {
    if (out) { try { *out = message; } catch (...) {} }
}
#ifndef _WIN32
void setErrno(std::string* out, const char* operation) noexcept {
    if (!out) return;
    try { *out = std::string(operation) + ": " + std::strerror(errno); } catch (...) {}
}
bool validPosixName(const std::string& n) { return n.size() > 1 && n[0] == '/' && n.find('/', 1) == std::string::npos; }
#endif
}

SharedMemoryRegion::~SharedMemoryRegion() { close(); }
SharedMemoryRegion::SharedMemoryRegion(SharedMemoryRegion&& o) noexcept { *this = std::move(o); }
SharedMemoryRegion& SharedMemoryRegion::operator=(SharedMemoryRegion&& o) noexcept {
    if (this == &o) return *this;
    close(); address_ = o.address_; block_ = o.block_; name_ = std::move(o.name_); creator_ = o.creator_;
#ifdef _WIN32
    handle_ = o.handle_; o.handle_ = nullptr;
#else
    fd_ = o.fd_; o.fd_ = -1;
#endif
    o.address_ = nullptr; o.block_ = nullptr; o.creator_ = false; o.name_.clear();
    return *this;
}

bool SharedMemoryRegion::create(const std::string& name, std::string* error) noexcept {
    close();
#ifdef _WIN32
    if (name.empty()) { setError(error, "mapping name is empty"); return false; }
    HANDLE h = CreateFileMappingA(INVALID_HANDLE_VALUE, nullptr, PAGE_READWRITE, 0,
                                  static_cast<DWORD>(sizeof(SharedBlock)), name.c_str());
    if (!h) { setError(error, "CreateFileMapping failed"); return false; }
    if (GetLastError() == ERROR_ALREADY_EXISTS) { CloseHandle(h); setError(error, "mapping already exists; choose a unique name"); return false; }
    void* p = MapViewOfFile(h, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(SharedBlock));
    if (!p) { CloseHandle(h); setError(error, "MapViewOfFile failed"); return false; }
    handle_ = h;
#else
    if (!validPosixName(name)) { setError(error, "POSIX shared-memory name must start with '/' and contain no other '/' characters"); return false; }
    int fd = shm_open(name.c_str(), O_CREAT | O_EXCL | O_RDWR, 0600);
    if (fd < 0) { setErrno(error, "shm_open(create)"); return false; }
    if (ftruncate(fd, static_cast<off_t>(sizeof(SharedBlock))) != 0) {
        setErrno(error, "ftruncate"); ::close(fd); shm_unlink(name.c_str()); return false;
    }
    void* p = mmap(nullptr, sizeof(SharedBlock), PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (p == MAP_FAILED) { setErrno(error, "mmap(create)"); ::close(fd); shm_unlink(name.c_str()); return false; }
    fd_ = fd;
#endif
    address_ = p; block_ = static_cast<SharedBlock*>(p); name_ = name; creator_ = true;
    // Start the C++ object lifetime in the mapped storage, including atomics.
    new (block_) SharedBlock();
    if (!block_->hostHeartbeat.is_lock_free() || !block_->pluginHeartbeat.is_lock_free() ||
        !block_->helperReady.is_lock_free() || !block_->slots[0].state.is_lock_free()) {
        unlinkName(nullptr); close(); setError(error, "required shared atomics are not lock-free on this platform"); return false;
    }
    return true;
}

bool SharedMemoryRegion::openExisting(const std::string& name, std::string* error) noexcept {
    close();
#ifdef _WIN32
    if (name.empty()) { setError(error, "mapping name is empty"); return false; }
    HANDLE h = OpenFileMappingA(FILE_MAP_ALL_ACCESS, FALSE, name.c_str());
    if (!h) { setError(error, "OpenFileMapping failed; is the host process running?"); return false; }
    void* p = MapViewOfFile(h, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(SharedBlock));
    if (!p) { CloseHandle(h); setError(error, "MapViewOfFile(open) failed"); return false; }
    handle_ = h;
#else
    if (!validPosixName(name)) { setError(error, "invalid POSIX shared-memory name"); return false; }
    int fd = shm_open(name.c_str(), O_RDWR, 0600);
    if (fd < 0) { setErrno(error, "shm_open(open)"); return false; }
    struct stat st{};
    if (fstat(fd, &st) != 0 || st.st_size != static_cast<off_t>(sizeof(SharedBlock))) {
        setError(error, "shared-memory region has an unexpected size"); ::close(fd); return false;
    }
    void* p = mmap(nullptr, sizeof(SharedBlock), PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (p == MAP_FAILED) { setErrno(error, "mmap(open)"); ::close(fd); return false; }
    fd_ = fd;
#endif
    address_ = p; block_ = static_cast<SharedBlock*>(p); name_ = name; creator_ = false;
    if (block_->magic != kMagic || block_->version != kProtocolVersion ||
        block_->slotCount != kSlotCount || block_->maxFrames != kMaxFrames) {
        close(); setError(error, "shared-memory protocol header mismatch"); return false;
    }
    if (!block_->hostHeartbeat.is_lock_free() || !block_->slots[0].state.is_lock_free()) {
        close(); setError(error, "shared atomics are not lock-free on this platform"); return false;
    }
    return true;
}

void SharedMemoryRegion::close() noexcept {
    if (address_) {
#ifdef _WIN32
        UnmapViewOfFile(address_);
#else
        munmap(address_, sizeof(SharedBlock));
#endif
    }
#ifdef _WIN32
    if (handle_) CloseHandle(static_cast<HANDLE>(handle_));
    handle_ = nullptr;
#else
    if (fd_ >= 0) ::close(fd_);
    fd_ = -1;
#endif
    address_ = nullptr; block_ = nullptr; name_.clear(); creator_ = false;
}

bool SharedMemoryRegion::unlinkName(std::string* error) noexcept {
#ifdef _WIN32
    (void)error; // Named mappings disappear when the last handle closes.
    return true;
#else
    if (!validPosixName(name_)) { setError(error, "no valid shared-memory name to unlink"); return false; }
    if (shm_unlink(name_.c_str()) != 0 && errno != ENOENT) { setErrno(error, "shm_unlink"); return false; }
    return true;
#endif
}
} // namespace voxciter_bridge
