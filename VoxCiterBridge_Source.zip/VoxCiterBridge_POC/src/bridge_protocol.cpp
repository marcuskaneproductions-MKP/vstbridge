#include "bridge_protocol.h"
// The protocol is currently header-only. This translation unit keeps the
// project layout ready for platform-specific shared-memory mapping code.
