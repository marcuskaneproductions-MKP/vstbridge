# Legacy Windows VST host side (not implemented yet)

The supplied Voxciter DLL is a 32-bit Windows PE binary. The helper must run in an environment that can load that architecture and must implement the VST2 host callbacks needed by the plug-in. It then claims `Ready` audio slots, runs the plug-in's process function, writes output, and marks the slot `Done`.

Still required:

- select and validate the Windows compatibility runtime for the target Intel Mac / Monterey version;
- build a 32-bit helper and load the VoxCiter DLL under that runtime;
- legally source the appropriate VST2 host ABI headers or use a reviewed compatible implementation;
- support VST lifecycle calls, sample-rate/block-size setup, parameter get/set, chunk/state save/restore, and error handling;
- test actual VoxCiter audio against a reference.

No Windows VST SDK or proprietary VoxCiter code is included in this repository scaffold.
